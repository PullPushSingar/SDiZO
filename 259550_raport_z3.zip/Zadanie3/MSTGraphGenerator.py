import random


def generate_mst_graph(n, waga_min, waga_max):
    # Inicjalizacja macierzy wag
    macierz = [[0 for j in range(n)] for i in range(n)]

    # Wypełnienie macierzy wag losowymi wartościami
    for i in range(n):
        for j in range(i + 1, n):
            waga = random.randint(waga_min, waga_max)
            macierz[i][j] = waga
            macierz[j][i] = waga

    # Zapis macierzy wag do pliku CSV
    with open("..\\graf.csv", "w") as plik:
        for i in range(n):
            plik.write(",".join(str(x) for x in macierz[i]) + "\n")

    print("Plik zapisany pomyslnie!")

    generate_mst_graph(1000, 1, 256)
