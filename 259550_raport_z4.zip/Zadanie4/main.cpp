#include <iostream>
#include <limits>

#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <thread>
#include <conio.h>
#include <queue>
#include <random>

using namespace std;
std::chrono::time_point<std::chrono::high_resolution_clock> start_time;

struct  Config{
    string numbersFilePath;
    string outputFile;
    string algorithmName;
    string timeResultPath;
    int numberOfElements;
    int maxWeight;
    int minWeight;
    bool generateGraph;
    bool deleteEges;



};

void startTimer();
long long stopTimer();
void progressAnimation();
void checkTime();
vector<int> readCsvFile(string fileName);
void saveResultsToCsv(Config config, vector<string> paths);
void saveTimeToScv(Config config, long long time, int MST);
void saveTimeToScv(Config config, long long time, int MST, int percents);
Config readCfgFile(string fileName);
int** createIntArrayFromVector(const std::vector<int>& vec, int n);
int** convertGraphToArray(const std::vector<std::vector<int>>& graph, int N);
void dijkstra(int **graph, int start, int dest,const  int n, const Config& cfg);
const int v = 6;
int generateRandomNumber(int min, int max);
void printAdjacencyMatrix(const std::vector<std::vector<int>>& adjacencyMatrix);
void printAdjacencyArray(int** adjacencyArray, int numVertices);
std::vector<std::vector<int>> readGraphFromCSV(const std::string& filename);
void deleteAdjacencyArray(int** adjacencyArray, int numVertices);
int** generateDirectedConnectedGraph(int numVertices, int maxWeight);
void saveAdjacencyMatrixToCSV(int** adjacencyMatrix, int numVertices, const std::string& filename);
int** readAdjacencyMatrixFromCSV(const std::string& filename, int& numVertices);
void deallocateMatrix(int** matrix, int numVertices);
vector<int> readCsvFile(string fileName);
int** createIntArrayFromVector(const std::vector<int>& vec, int n);
int ** createSubArray(int **arr,const int orginalSize,const  int subArraySize);


int main() {
    const Config cfg = readCfgFile(R"(C:\Users\huber\Desktop\0STUDIA\SDIZO\SDiZO\Zadanie4\Config.cfg)");
    std::string filename = R"(C:\Users\huber\Desktop\0STUDIA\SDIZO\SDiZO\Zadanie4\macierzDijkstry.csv)";  // Nazwa pliku do zapisu

    startTimer();


    std::vector <int> intVector = readCsvFile(R"(C:\Users\huber\Desktop\0STUDIA\SDIZO\SDiZO\Zadanie4\macierzDijkstry.csv)");
    int **arr =  createIntArrayFromVector(intVector,1000);
    int ** graph = createSubArray(arr,1000,cfg.numberOfElements);
    deallocateMatrix(arr,1000);







    int startVertex = 0;
    int destVertex = 400;

    dijkstra(graph,0,cfg.numberOfElements/2,cfg.numberOfElements,cfg);


    deallocateMatrix(graph,cfg.numberOfElements);
   return 0;
}




//
//{ 0, 0, 2, 0, 5, 0 },
//{ 7, 0, 0, 2, 0, 0 },
//{ 0, 0, 0, 0, 0, 12 },
//{ 0, 0, 10, 0, 0, 0 },
//{ 0, 3, 6, 8, 0, 0 },
//{ 0, 0, 0, -20, 3, 0 }


Config readCfgFile(string fileName) {
    ifstream configFile(fileName);
    Config config;
    string  linia;
    if (configFile.is_open())
    {
        while(getline(configFile,linia))
        {

            if (linia.find("Plik z danymi         :") != string::npos){
                string text = "Plik z danymi         :";
                size_t  pos = linia.find(text);
                string  path = linia.erase(pos,text.length());
                config.numbersFilePath = path;
            }
            if (linia.find("Wyliczona sciezka     :") != string::npos){
                string text = "Wyliczona sciezka     :";
                size_t pos = linia.find(text);
                string  path = linia.erase(pos,text.length());
                config.outputFile = path;
            }
            if (linia.find("Algorytm              :") != string::npos){
                string text = "Algorytm              :";
                size_t pos = linia.find(text);
                string  alghorithm = linia.erase(pos,text.length());
                config.algorithmName = alghorithm;
            }
            if (linia.find("Rozmiar danych        :") != string::npos){
                string text = "Rozmiar danych        :";
                size_t pos = linia.find(text);
                string  elements = linia.erase(pos,text.length());
                config.numberOfElements = stoi(elements);
            }

            if (linia.find("Wyniki czasowe        :") != string::npos){
                string text = "Wyniki czasowe        :";
                size_t pos = linia.find(text);
                string  path = linia.erase(pos,text.length());
                config.timeResultPath = path;

            }





            }

        }

    else {
        std::error_code ec = std::make_error_code(std::errc::io_error);
        cout << "Nie udało się otworzyć pliku. Kod błędu: " << ec.value() << ", komunikat: " << ec.message() << endl;
        exit(50);
    }
    configFile.close();
    return config;

}

vector<int> readCsvFile(string fileName) {
    ifstream csvFile(fileName);
    vector<int> numbersVector;

    if (csvFile.is_open()) {
        string line;
        while (getline(csvFile, line)) {
            stringstream ss(line);
            string value;
            while (getline(ss, value, ',')) {
                int number = stoi(value);
                numbersVector.push_back(number);
            }
        }
    }   else {
        std::error_code ec = std::make_error_code(std::errc::io_error);
        cout << "Nie udało się otworzyć pliku. Kod błędu: " << ec.value() << ", komunikat: " << ec.message() << endl;
        exit(0);
    }
    csvFile.close();

    return numbersVector;
}

void startTimer() {
    start_time = std::chrono::high_resolution_clock::now();
}
long long stopTimer() {
    std::chrono::time_point<std::chrono::high_resolution_clock> end_time = std::chrono::high_resolution_clock::now();
    auto elapsed_time = std::chrono::duration_cast<std::chrono::nanoseconds>(end_time - start_time).count();
    return elapsed_time;
}

int **createIntArrayFromVector(const std::vector<int>& vec,const int n) {
    const int rows = n;
    const int cols = n;
    int ** arr = new int*[rows];
    for (int i = 0; i < rows; ++i){
        arr[i] = new int[cols];
    }

    for (int i = 0;  i < rows; i++){
        for (int j = 0;  j < cols; j++)
            arr[i][j] = vec[i * n + j];

    }


    return arr;
}

int generateRandomNumber(int min, int max) {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_int_distribution<int> distribution(min, max);
    return distribution(gen);
}



void printAdjacencyMatrix(const std::vector<std::vector<int>>& adjacencyMatrix) {
    int numVertices = adjacencyMatrix.size();
    for (int i = 0; i < numVertices; ++i) {
        for (int j = 0; j < numVertices; ++j) {
            std::cout << adjacencyMatrix[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

void printAdjacencyArray(int** adjacencyArray, int numVertices) {
    for (int i = 0; i < numVertices; ++i) {
        for (int j = 0; j < numVertices; ++j) {
            std::cout << adjacencyArray[i][j] << " ";
        }
        std::cout << std::endl;
    }
}





std::vector<std::vector<int>> readGraphFromCSV(const std::string& filename) {
    std::ifstream file(filename);
    std::vector<std::vector<int>> adjacencyMatrix;

    if (file.is_open()) {
        std::string line;


        if (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string cell;


            std::getline(ss, cell, ',');


            while (std::getline(ss, cell, ',')) {

                try {
                    int vertex = std::stoi(cell);
                    adjacencyMatrix.emplace_back();
                } catch (const std::exception& e) {
                    break;
                }
            }
        }


        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string cell;
            int row = adjacencyMatrix.size();


            std::getline(ss, cell, ',');


            int col = 0;
            while (std::getline(ss, cell, ',')) {

                try {
                    int weight = std::stoi(cell);
                    adjacencyMatrix[row].push_back(weight);
                    col++;
                } catch (const std::exception& e) {
                    break;
                }
            }


            if (col != adjacencyMatrix.size()) {
                adjacencyMatrix.clear();
                break;
            }
        }

        std::cout << "Odczytano graf z pliku " << filename << std::endl;
    } else {
        std::cerr << "Nie można otworzyć pliku " << filename << " do odczytu." << std::endl;
    }

    file.close();
    return adjacencyMatrix;
}
void dijkstra(int **graph, int start, int dest,const  int n, const Config& cfg) {
    long long timer = 0;
    int distances[n];
    int prev[n];
    bool visited[n];
    int finalDistance;
    std::vector <string> vectorPaths;

    for (int i = 0; i < n; i ++){
        visited[i] = false;
    }

    for (int i = 0; i < n; i++) {
        distances[i] = numeric_limits<int>::max();
        prev[i] = -1;
    }

    distances[start] = 0;

    for (int count = 0; count < n - 1; count++) {
        int u = -1;
        int minDist = numeric_limits<int>::max();


        for (int i = 0; i < n; i++) {
            if (!visited[i] && distances[i] < minDist) {
                minDist = distances[i];
                u = i;
            }
        }


        visited[u] = true;


        for (int v = 0; v < n; v++) {
            if (!visited[v] && graph[u][v] != 0 && distances[u] != numeric_limits<int>::max() &&
                distances[u] + graph[u][v] < distances[v]) {
                distances[v] = distances[u] + graph[u][v];
                prev[v] = u;
            }
        }
    }


    if (distances[dest] == numeric_limits<int>::max()) {
        cout << "No path from node " << start << " to node " << dest << endl;
        finalDistance = numeric_limits<int>::max();
    } else {
        cout << "Shortest path from node " << start << " to node " << dest << " has length " << distances[dest] << endl;

        finalDistance = distances[dest];
        cout << "Path: ";
        int u = dest;
        int path[v];
        int pathIndex = 0;

        while (u != -1) {
            path[pathIndex++] = u;
            u = prev[u];
        }

        for (int i = pathIndex - 1; i >= 0; i--) {
            cout << path[i];
            if (i > 0) {
                cout << " -> ";
            }
        }
        cout << endl;
   }
    timer = stopTimer();
    saveTimeToScv(cfg,timer,finalDistance);
}

int** convertGraphToArray(const std::vector<std::vector<int>>& graph, int N) {

    // Tworzenie tablicy dwuwymiarowej
    int** adjacencyArray = new int*[N];
    for (int i = 0; i < N; ++i) {
        adjacencyArray[i] = new int[N];
        for (int j = 0; j < N; ++j) {
            adjacencyArray[i][j] = graph[i][j];
        }
    }
    cout << "123";
    return adjacencyArray;
}

int** generateDirectedConnectedGraph(int numVertices, int maxWeight) {
    int** adjacencyMatrix = new int*[numVertices];

    for (int i = 0; i < numVertices; ++i) {
        adjacencyMatrix[i] = new int[numVertices];
    }

    // Inicjalizacja tablicy zerami
    for (int i = 0; i < numVertices; ++i) {
        for (int j = 0; j < numVertices; ++j) {
            adjacencyMatrix[i][j] = 0;
        }
    }

    // Połączenia między wierzchołkami
    for (int i = 0; i < numVertices; ++i) {
        for (int j = i + 1; j < numVertices; ++j) {
            if (i != j) {
                int weight = generateRandomNumber(1, maxWeight);  // Losowa waga krawędzi
                adjacencyMatrix[i][j] = weight;
            }
        }
    }

    return adjacencyMatrix;
}

void saveAdjacencyMatrixToCSV(int** adjacencyMatrix, int numVertices, const std::string& filename) {
    std::ofstream outputFile(filename);

    if (outputFile.is_open()) {
        for (int i = 0; i < numVertices; ++i) {
            for (int j = 0; j < numVertices; ++j) {
                outputFile << adjacencyMatrix[i][j];
                if (j != numVertices - 1) {
                    outputFile << ",";
                }
            }
            outputFile << std::endl;
        }

        outputFile.close();
        std::cout << "Zapisano macierz sąsiedztwa do pliku: " << filename << std::endl;
    } else {
        std::cout << "Nie można otworzyć pliku do zapisu: " << filename << std::endl;
    }
}

int** readAdjacencyMatrixFromCSV(const std::string& filename, int& numVertices) {
    std::ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        std::cout << "Nie można otworzyć pliku do odczytu: " << filename << std::endl;
        return nullptr;
    }

    std::vector<std::vector<int>> adjacencyMatrix;
    std::string line;
    while (std::getline(inputFile, line)) {
        std::vector<int> row;
        std::istringstream iss(line);
        std::string value;
        while (std::getline(iss, value, ',')) {
            row.push_back(std::stoi(value));
        }
        adjacencyMatrix.push_back(row);
    }

    numVertices = adjacencyMatrix.size();


    int** matrix = new int*[numVertices];
    for (int i = 0; i < numVertices; ++i) {
        matrix[i] = new int[numVertices];
        for (int j = 0; j < numVertices; ++j) {
            matrix[i][j] = adjacencyMatrix[i][j];
        }
    }

    return matrix;
}

void deallocateMatrix(int** matrix, int numVertices) {
    for (int i = 0; i < numVertices; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

void saveTimeToScv(Config config, long long time, int MST) {
    string path;

    path = config.timeResultPath + "\\TimeAndMST.csv";
    std::ofstream outfile;
    outfile.open(path, ios::app);
    outfile  << config.algorithmName << " " << std::to_string(config.numberOfElements) << "  " << MST  <<" " << std::to_string(time) << " ns " << "\n";
    outfile.close();

}

int ** createSubArray(int **arr,const int orginalSize, const int subArraySize){
    int ** subArray = new int*[subArraySize];
    for (int i = 0; i < subArraySize; ++i){
        subArray[i] = new int[subArraySize];
    }

    for (int i = 0; i < subArraySize; i ++){
        for (int j = 0; j < subArraySize; j ++)
        subArray[i][j] = arr[i][j];


    }

    return subArray;

}



